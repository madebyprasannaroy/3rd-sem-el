// Dashboard: role-specific home. Customers/manufacturers see their own scans; inspectors see every scan live.
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { supabaseUser } from "@/lib/supabaseServer";
import LiveScanList, { type ScanRow } from "@/components/LiveScanList";
import SignOut from "@/components/SignOut";

export const dynamic = "force-dynamic"; // always fetch fresh data for the signed-in user

const TITLES = { customer: "Customer dashboard", manufacturer: "Manufacturer dashboard", inspector: "Inspector dashboard" } as const;

export default async function Dashboard() {
  const session = await getSession();
  if (!session) redirect("/login");
  // RLS decides what comes back: own scans for customer/manufacturer, all scans for inspector.
  const { data } = await supabaseUser().from("scans").select("id,title,status,scan_type,owner_id,created_at").order("created_at", { ascending: false });
  const canScan = true; // all three roles may start a scan in Phase 1
  return (
    <main>
      <div className="row"><h1>{TITLES[session.role]}</h1><SignOut /></div>
      {canScan && <p><Link className="btn" href="/scan/new">{session.role === "manufacturer" ? "Upload a draft label" : "New scan"}</Link></p>}
      <LiveScanList initial={(data ?? []) as ScanRow[]} showOwner={session.role === "inspector"} />
    </main>
  );
}
