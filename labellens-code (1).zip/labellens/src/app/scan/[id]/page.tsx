// Scan page (server part): loads the scan, its fields and signed photo URLs under the user's permissions, then renders the live view.
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { supabaseUser } from "@/lib/supabaseServer";
import ScanView, { type Field, type Photo } from "@/components/ScanView";

export const dynamic = "force-dynamic";

export default async function ScanPage({ params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) redirect("/login");
  const sb = supabaseUser();
  // RLS returns nothing if this user may not see the scan, which becomes a 404.
  const { data: scan } = await sb.from("scans").select("id,title,status,owner_id").eq("id", params.id).single();
  if (!scan) notFound();
  const { data: fields } = await sb.from("extracted_fields").select("id,key,value,unit,confidence,status").eq("scan_id", params.id).order("key");
  const { data: assets } = await sb.from("image_assets").select("id,panel,storage_key").eq("scan_id", params.id);
  // Short-lived signed URLs (10 min) because the image bucket is private.
  const photos: Photo[] = await Promise.all((assets ?? []).map(async (a) => {
    const { data } = await sb.storage.from("scan-images").createSignedUrl(a.storage_key, 600);
    return { id: a.id, panel: a.panel, url: data?.signedUrl ?? null };
  }));
  return (
    <main>
      <p><Link href="/dashboard">← Back</Link></p>
      <h1>{scan.title ?? "Untitled scan"}</h1>
      {/* Only the owner may edit values; inspectors view read-only (matches the database policy). */}
      <ScanView scanId={scan.id} initialStatus={scan.status} initialFields={(fields ?? []) as Field[]} photos={photos} canEdit={scan.owner_id === session.userId} />
    </main>
  );
}
