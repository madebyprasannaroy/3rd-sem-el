"use client";
// New scan page: creates a scan, lets the user take/pick a photo per panel (phone camera supported), uploads, then starts extraction.
import { useState } from "react";

const PANELS = [
  { key: "front", label: "Front of pack" },
  { key: "ingredients", label: "Ingredients" },
  { key: "nutrition", label: "Nutrition table" },
  { key: "declaration", label: "Declarations (MRP, net qty, manufacturer)" },
] as const;

export default function NewScan() {
  const [title, setTitle] = useState("");
  const [files, setFiles] = useState<Record<string, File | undefined>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Runs the whole flow: create scan -> upload each chosen photo -> extract -> open the scan page.
  async function submit() {
    setBusy(true); setError(null);
    try {
      const created = await fetch("/api/scans", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title }) });
      if (!created.ok) throw new Error((await created.json()).error ?? "Could not create scan");
      const { id } = await created.json();
      for (const p of PANELS) {
        const f = files[p.key];
        if (!f) continue;
        const fd = new FormData(); fd.append("file", f); fd.append("panel", p.key);
        const up = await fetch(`/api/scans/${id}/images`, { method: "POST", body: fd });
        if (!up.ok) throw new Error(`${p.label}: ${(await up.json()).error ?? "upload failed"}`);
      }
      // Open the scan page right away so the user watches status change live; extraction continues in the background.
      fetch(`/api/scans/${id}/extract`, { method: "POST" });
      window.location.href = `/scan/${id}`;
    } catch (e) { setError((e as Error).message); setBusy(false); }
  }

  const count = Object.values(files).filter(Boolean).length;
  return (
    <main>
      <h1>New scan</h1>
      <div className="card">
        <label>Title (optional)<input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} /></label>
        {PANELS.map((p) => (
          <label key={p.key}>{p.label}
            {/* capture="environment" opens the rear camera on phones; on a laptop it opens the file picker */}
            <input type="file" accept="image/*" capture="environment" onChange={(e) => setFiles({ ...files, [p.key]: e.target.files?.[0] })} />
          </label>
        ))}
        {error && <p className="error">{error}</p>}
        <p><button disabled={busy || count === 0} onClick={submit}>{busy ? "Uploading…" : `Upload ${count} photo${count === 1 ? "" : "s"}`}</button></p>
      </div>
    </main>
  );
}
