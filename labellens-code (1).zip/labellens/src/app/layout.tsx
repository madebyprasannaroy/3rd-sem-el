// Root layout: wraps every page with the HTML shell, mobile viewport, and shared styles.
import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = { title: "LabelLens", description: "AI food label intelligence (Phase 1 demo)" };
export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>);
}
