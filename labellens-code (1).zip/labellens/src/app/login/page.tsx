"use client";
// Login page: email + password sign-in only (no public sign-up; accounts are created by the seed script).
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseBrowser";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  // Signs in with Supabase Auth, then goes to the dashboard (which shows the view for the user's role).
  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabaseBrowser().auth.signInWithPassword({ email, password });
    if (error) setError("Sign-in failed. Check your email and password.");
    else window.location.href = "/dashboard";
  }

  return (
    <main>
      <h1>LabelLens sign in</h1>
      <form className="card" onSubmit={signIn}>
        <label>Email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
        <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        {error && <p className="error">{error}</p>}
        <p><button type="submit">Sign in</button></p>
      </form>
    </main>
  );
}
