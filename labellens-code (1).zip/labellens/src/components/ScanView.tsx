"use client";
// Scan detail view: shows status, photos and extracted fields live, and lets the owner correct fields (each edit is audited).
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseBrowser";

export interface Field { id: string; key: string; value: string | null; unit: string | null; confidence: number | null; status: string; }
export interface Photo { id: string; panel: string; url: string | null; }

export default function ScanView(props: { scanId: string; initialStatus: string; initialFields: Field[]; photos: Photo[]; canEdit: boolean }) {
  const [status, setStatus] = useState(props.initialStatus);
  const [fields, setFields] = useState<Field[]>(props.initialFields);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    const sb = supabaseBrowser();
    // Live updates for this scan only: status changes, new fields from extraction, and corrections made on other devices.
    const ch = sb.channel(`scan-${props.scanId}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "scans", filter: `id=eq.${props.scanId}` }, (p) => setStatus((p.new as { status: string }).status))
      .on("postgres_changes", { event: "*", schema: "public", table: "extracted_fields", filter: `scan_id=eq.${props.scanId}` }, (p) => {
        const row = p.new as Field;
        setFields((cur) => cur.some((f) => f.id === row.id) ? cur.map((f) => (f.id === row.id ? { ...f, ...row } : f)) : [...cur, row]);
      }).subscribe();
    return () => { sb.removeChannel(ch); };
  }, [props.scanId]);

  // Sends a corrected value to the server; the live subscription then refreshes every open screen.
  async function save(f: Field, value: string) {
    setMsg(null);
    const r = await fetch(`/api/scans/${props.scanId}/fields/${f.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ value }) });
    setMsg(r.ok ? `Saved ${f.key}` : "Could not save");
  }

  return (
    <div>
      <p>Status: <span className={`badge ${status}`}>{status}</span></p>
      <div className="row">{props.photos.map((p) => p.url && <figure key={p.id} style={{ margin: 0 }}><img src={p.url} alt={p.panel} width={140} /><figcaption className="muted">{p.panel}</figcaption></figure>)}</div>
      <h2>Extracted fields</h2>
      <p className="muted">Phase 1 uses sample (stub) extraction. Values marked uncertain or missing need your review; nothing is invented.</p>
      {fields.length === 0 && <p className="muted">Waiting for extraction…</p>}
      <table><thead><tr><th>Field</th><th>Value</th><th>Confidence</th><th>Status</th></tr></thead><tbody>
        {fields.map((f) => (
          <tr key={f.id}>
            <td>{f.key}</td>
            <td>{props.canEdit
              // Editable input; saves when the user leaves the box. Uses `key` so live updates refresh the shown value.
              ? <input key={f.value ?? ""} defaultValue={f.value ?? ""} placeholder="(missing: type value)" onBlur={(e) => e.target.value && e.target.value !== (f.value ?? "") && save(f, e.target.value)} />
              : (f.value ?? <em>missing</em>)} {f.unit}</td>
            <td>{f.confidence != null ? Math.round(f.confidence * 100) + "%" : "-"}</td>
            <td><span className={`badge ${f.status}`}>{f.status}</span></td>
          </tr>))}
      </tbody></table>
      {msg && <p className="muted">{msg}</p>}
    </div>
  );
}
