"use client";
// Live scan list: shows scans and updates instantly via Supabase Realtime when any scan is added or changes status.
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabaseBrowser";

export interface ScanRow { id: string; title: string | null; status: string; scan_type: string; owner_id: string; created_at: string; }

export default function LiveScanList({ initial, showOwner }: { initial: ScanRow[]; showOwner: boolean }) {
  const [scans, setScans] = useState<ScanRow[]>(initial);

  useEffect(() => {
    const sb = supabaseBrowser();
    // Subscribe to all changes on scans; RLS already limits which rows this user is sent.
    const channel = sb.channel("scans-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "scans" }, (payload) => {
        const row = payload.new as ScanRow;
        // Merge the changed row into local state (insert new, or replace existing), newest first.
        setScans((cur) => [row, ...cur.filter((s) => s.id !== row.id)]
          .sort((a, b) => b.created_at.localeCompare(a.created_at)));
      })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, []);

  if (scans.length === 0) return <p className="muted">No scans yet.</p>;
  return (
    <div>
      {scans.map((s) => (
        <div className="card row" key={s.id}>
          <div>
            <Link href={`/scan/${s.id}`}><strong>{s.title ?? "Untitled scan"}</strong></Link>
            <div className="muted">{s.scan_type === "draft_label" ? "Draft label" : "Product"} · {new Date(s.created_at).toLocaleTimeString()}{showOwner ? ` · ${s.owner_id.slice(0, 8)}` : ""}</div>
          </div>
          <span className={`badge ${s.status}`}>{s.status}</span>
        </div>
      ))}
    </div>
  );
}
