// Browser Supabase client: used by client components for sign-in and live (realtime) subscriptions. Uses the public anon key only.
import { createBrowserClient } from "@supabase/ssr";

// Creates a Supabase client for the browser; row-level security limits what it can read.
export function supabaseBrowser() {
  return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
}
