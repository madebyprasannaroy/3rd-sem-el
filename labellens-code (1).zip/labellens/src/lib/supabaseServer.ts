// Server Supabase clients: one acting as the signed-in user (RLS applies) and one with the service role (server-only, after authorization).
import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";

// Creates a client bound to the request's session cookies, so every query runs as the logged-in user under RLS.
export function supabaseUser() {
  const store = cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => store.getAll(),
      // Cookie writes can fail inside Server Components; middleware refreshes the session, so ignoring is safe.
      setAll: (list: { name: string; value: string; options?: CookieOptions }[]) => { try { list.forEach(({ name, value, options }) => store.set(name, value, options)); } catch {} },
    },
  });
}

// Creates a privileged client that bypasses RLS. NEVER import this from client code; use only after checking permissions.
export function supabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false },
  });
}
