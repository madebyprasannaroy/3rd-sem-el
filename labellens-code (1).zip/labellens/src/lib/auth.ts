// Auth helper for server code: returns the current user and their role (or null), so routes can enforce permissions.
import { supabaseUser } from "./supabaseServer";
import { isRole, type Role } from "@/core/roles";

export interface Session { userId: string; role: Role; }

// Reads the verified user from Supabase, then looks up their role in profiles. Returns null if not signed in or no valid role.
export async function getSession(): Promise<Session | null> {
  const sb = supabaseUser();
  const { data: { user } } = await sb.auth.getUser(); // getUser() verifies the token with Supabase (not just the cookie)
  if (!user) return null;
  const { data } = await sb.from("profiles").select("role").eq("id", user.id).single();
  if (!data || !isRole(data.role)) return null;
  return { userId: user.id, role: data.role };
}
